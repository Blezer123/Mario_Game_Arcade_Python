<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Menu_Textures_Levels" tilewidth="64" tileheight="64" tilecount="49" columns="7">
 <image source="../images/Menu_Textures.png" width="500" height="500"/>
</tileset>
